<div class="copyrights">
	 <p>© 2019 BCG. All Rights Reserved |  <a href="#">BCG</a> </p>
</div>	
