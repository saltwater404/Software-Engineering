<?php
session_start();
if(isset($_POST['signin']))
{
$email=$_POST['email'];
$password=md5($_POST['password']);
$sql ="SELECT EmailId,Password FROM tblusers WHERE EmailId=:email and Password=:password";
$query= $dbh -> prepare($sql);
$query-> bindParam(':email', $email, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
$_SESSION['login']=$_POST['email'];
echo "<script type='text/javascript'> document.location = 'package-list.php'; </script>";
} else{
	
	echo "<script>alert('Invalid Details');</script>";

}

}

?>
<style>
    .modal-info{
        width:80%;
        background: #fff;
    }
    .a{
        padding:10px 0px;
    }
    .a h2{
        text-align: center;
        padding-bottom: 30px;
        border-top:3px solid #5a5ac1;
    }
    .a h3{
        padding-bottom: 30px;
    }
    .b{
        clear: both;
        padding:20px 0px;
    }
    .b ul li{
        float: left;
        list-style-type: none;
    }
    .b ul li img{
        width:70px;
        overflow: hidden;
        margin-right: 10px; 
    }
    .b ul li a{
        margin-left:20px;
    }
    
</style>

<div class="modal fade" id="myModal5" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content modal-info">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
<div class="modal-body modal-spa">
                <div class="a">
                    <h2><a href="dpg.php" target="_blank">Dhaka City:</a></h2>

                    <h3><a href="dpg.php" target="_blank">Hot Links : Click To visit the main page</a></h3>
                    <div class="b">
                        <ul>
                            <li><img src="images/1.jpg" alt=""></li>
                            <li><a href="#">Visit Lalbagh Kella</a></li>
                        </ul>
                    </div>
                    <div class="b">
                        <ul>
                            <li><img src="images/1.jpg" alt=""></li>
                            <li><a href="#">Visit National Zoo At Mirpur</a></li>
                        </ul>
                    </div>
                    <div class="b">
                        <ul>
                            <li><img src="images/1.jpg" alt=""></li>
                            <li><a href="#">Visit National Parliament House</a></li>
                        </ul>
                    </div>
                    <div class="b">
                        <ul>
                            <li><img src="images/1.jpg" alt=""></li>
                            <li><a href="#">Shopping At Boshundhara Shopping Mall</a></li>
                        </ul>
                    </div>
                    
                    
                </div>
            </div>
        </div>
    </div>
</div>